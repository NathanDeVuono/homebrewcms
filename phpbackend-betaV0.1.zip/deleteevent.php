<?php
  require 'deleteconfirm.js';
  
?>